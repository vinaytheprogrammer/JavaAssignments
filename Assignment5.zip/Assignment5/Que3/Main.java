
public class Main {
    public static void main(String[] args) {

        Concrete i1 = new Concrete();
        i1.im1();
        i1.im2();
        i1.dm1();
        Concrete2 i2 = new Concrete2();
        i2.im1();
        i2.im2();
        i2.dm1();
    }
}