class Concrete2 implements Iface1, Iface2 {
    public void im1() {
        System.out.println("I'm im1() of Concrete2");

    }

    public void im2() {
        System.out.println("I'm im2() in Concrete2");
    }

    public void dm1() {
        System.out.println("I'm dm1() of Concrete2");

    }
}