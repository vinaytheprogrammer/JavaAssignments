//import hospitals.*;
import inst.nitjsr.hospitals.dblayer.*;
class Main 
{
    public static void main(String[] args) {
    
        Doctor d1= new Doctor();
        Doctor d2= new Doctor();

        d1.delete(8);
    }
}