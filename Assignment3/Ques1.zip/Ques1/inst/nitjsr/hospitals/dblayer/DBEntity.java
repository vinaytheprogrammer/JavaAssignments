package inst.nitjsr.hospitals.dblayer;
// Define the DBEntity interface
public interface DBEntity {
    void insert(DBEntity entity);
    void delete(int id);
    void update(int id, DBEntity entity);
}