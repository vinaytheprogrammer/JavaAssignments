import inst.nitjsr.hospitals.dblayer.*;

class Main 
{
    public static void main(String[] args) {
        Doctor d=new Doctor();
        d.setId(1);
        d.setName("Vinay");
        d.setSpecialization("Programming");
        d.setChamberFloor("Hostel-K");
        
        Doctor d2=new Doctor();
        d2.insert(d);
        d2.delete(1);
        d2.update(1, d);


    }
}